import requestUtil from '../../../utils/requestUtil.js';
import _DuoguanData, { duoguan_host_api_url as API_HOST } from '../../../utils/data';
import dg from '../../../utils/dg.js';
var app = getApp()
//选项卡
Page({
  data: {
      cateList:[]
    },
    //显示隐藏
    isShow_bind:function(e){
      var that = this
      var datas = that.data.cateList
      for(var i=0;i<datas.length;i++){
          if(datas[i].id == e.currentTarget.id){
              var isShow = (datas[i].isshow == true)?false:true;
              datas[i].isshow = isShow
          }
      }
      that.setData({
          cateList:datas,
      })
    },
    onShow:function(){
      var that = this
      //请求板块列表
      var data = {
        _: Date.now()
      };
      requestUtil.get(_DuoguanData.duoguan_get_bbs_cate_url,data,(info)=>{},that,{
        completeAfter:function(res){
          that.initBbsCateData(res.data);
        }
      });
    },
    initBbsCateData:function(data){
      var that = this
      that.setData({
          cateList:data.info,
      })
    },
    //跳转板块
    forumlist_bind:function(e){
      wx.redirectTo({
        url: '../forumlist/forumlist?wid='+e.currentTarget.id+'&cname='+e.currentTarget.dataset.name
      })
    },
    //下拉刷新
    onPullDownRefresh:function(){
      var that = this
      var data = {
        _: Date.now()
      };
      requestUtil.get(_DuoguanData.duoguan_get_bbs_cate_url,data,(info)=>{},that,{
        completeAfter:function(res){
          that.initBbsCateData(res.data)
        }
      });
      setTimeout(()=>{
        wx.stopPullDownRefresh()
      },1000)
    },
})